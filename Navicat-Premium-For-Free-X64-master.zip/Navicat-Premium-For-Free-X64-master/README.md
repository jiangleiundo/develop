# Navicat Premium11.0.10.0 x64

 破解版方法 :
 
1.双击安装

2.把Patch.exe拷贝到程序安装目录

3.双击运行Patch.exe 破解完成
