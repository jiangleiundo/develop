# YUI-Compressor
Compresses javascript and css using YUI-Compressor <http://yuilibrary.com/download/yuicompressor/>

## Installation
Use package control <http://wbond.net/sublime_packages/package_control> and search for YUI Compressor

## Gettings started
Make sure you have java installed and that it's on the path.
On linux and OSX it's usually added by default, but on windows you need to add it.
<http://java.com/en/download/help/path.xml>

make sure you can run `java -version` from the terminal / command prompt.

Open a .js or .css file and press `F7` or `command + b`.

The plugin generates a new files with the extension `.min.js` or `.min.css`
