module.exports = process.binding('fs').exports();
