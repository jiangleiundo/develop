module.exports = process.binding('child_process').exports();
