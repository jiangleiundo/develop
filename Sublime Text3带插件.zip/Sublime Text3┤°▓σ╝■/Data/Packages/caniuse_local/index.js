/** default boot file **/

/**
    NOTE: while you update (add or remove) commands
    you may restart sublime text or resave the v8.py file 
    in plugin SublimeJS to make changes effect
 */
defineCommand("Caniuse", require("caniuse.command"));
